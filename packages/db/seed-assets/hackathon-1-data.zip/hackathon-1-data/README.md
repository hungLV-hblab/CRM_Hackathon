# Bộ dữ liệu chấm điểm — CRM AI Fusion (Hackathon 15/08/2026)

Dữ liệu thật của 5 sales (Thảo, Vân, Phúc, Linh, Huệ), chuẩn hoá theo `huong-dan-nhap-du-lieu-mau.md` và luật chấm ở `thang-cham-diem-sales.md`. Mốc "hôm nay" = **2026-08-15**. Tiền tính bằng đơn vị ghi ở cột `currency`/`Đơn vị tiền tệ` tương ứng (chủ yếu JPY, một số USD/WON).

## 1. Danh sách file

| File | Số dòng | Vai trò |
|---|---:|---|
| `Account.csv` | 25 công ty | Hồ sơ công ty |
| `Contacts.csv` | 38 người | Đầu mối liên hệ mỗi công ty |
| `Opps.csv` | 23 cơ hội | Cơ hội bán hàng đang theo dõi |
| `Snapshots.csv` | 172 bản chụp | Chỉ mục các file HTML trong `snapshot/` |
| `snapshot/` | 172 file `.html` | Nội dung web thật (trước/sau), nguồn cho AI đọc |

Tổng cộng **25 công ty** (`C15`–`C39`), chia đều 5 công ty/sales, trừ Vân (5) và các sales còn lại theo đúng luật chấm.

---

## 2. `Account.csv` — Hồ sơ công ty

| Cột | Ý nghĩa |
|---|---|
| `company_code` | Mã duy nhất, khoá chính. Dạng `C15`–`C39`. |
| `company_name` | Tên công ty. |
| `sales_owner` | Sales phụ trách (Thảo / Vân / Phúc / Linh / Huệ). |
| `industry` | Ngành kinh doanh. |
| `company_type` | Một trong 5 loại: `Traditional`, `IT Solution`, `IT Product`, `Tech-based/Startup`, `ITO khác`. Với công ty tư vấn/AI/fintech không khớp thẳng 5 loại gốc, đã quy đổi hợp lý nhất (ví dụ `IT Consulting` giữ nguyên cho nhóm của Linh). |
| `country` | Quốc gia. |
| `company_size` | Khoảng số nhân sự. Có thể trống. |
| `website_url` | Trang chủ công ty — nguồn gốc của các bản chụp. **Trống với `C32`** (CY&SONS không có website riêng, chỉ có LinkedIn — xem `notes`). |
| `is_tracked` | `Có`/`Không` — cờ "Đang theo dõi" dùng cho vòng quét nhóm 5. |
| `notes` | Ghi chú nghiệp vụ tự do do sales cung cấp, có thể nhiều dòng. |

---

## 3. `Contacts.csv` — Người liên hệ

| Cột | Ý nghĩa |
|---|---|
| `contact_code` | Mã duy nhất, dạng `P31`–`P68`. |
| `company_code` | Công ty sở hữu — khoá ngoại tới `Account.csv`. |
| `full_name`, `job_title`, `email`, `phone` | Thông tin cá nhân. |
| `is_primary_contact` | `Có`/`Không`. **Mỗi công ty đúng một** người `Có` — đây là PIC (người sở hữu nỗi đau, không nhất thiết chức danh cao nhất). |

> **Lưu ý quan trọng:** toàn bộ 38 người liên hệ là **nhân vật ảo** do BTC tạo để đủ dữ liệu demo (tên/chức danh/email hợp lý theo quốc gia và loại công ty, email khớp domain website). Không phải người thật sales đang làm việc cùng.

---

## 4. `Opps.csv` — Cơ hội bán hàng

| Cột | Ý nghĩa |
|---|---|
| `opportunity_code` | Mã duy nhất, dạng `O9`–`O23` (`O1`–`O8` là bộ demo hư cấu riêng, không nằm trong file này). |
| `company_code` | Công ty sở hữu cơ hội. |
| `sales_owner` | Phải khớp `sales_owner` của công ty ở `Account.csv`. |
| `opportunity_name`, `expected_value`, `currency`, `expected_close_month` | Thông tin thương vụ. |
| `stage` | **Đúng 1 trong 7 giá trị chuẩn**: `Tiếp cận` → `Đủ điều kiện` → `Soạn đề xuất` → `Thương lượng` → `Thắng` / `Thua` / `Tạm dừng`. |
| `primary_contact_code` | Người đầu mối cho cơ hội này — khoá ngoại tới `Contacts.csv`, luôn thuộc đúng `company_code`. |
| `need_signal`, `budget_signal` | Dấu hiệu nhu cầu / ngân sách — bắt buộc với cơ hội từ `Đủ điều kiện` trở lên. |
| `next_action`, `due_date` | Việc tiếp theo + hạn — bắt buộc với cơ hội đang mở. |
| `lost_reason` | Bắt buộc khi `stage = Thua`. |
| `notes` | Ghi chú, gồm cả các dòng cảnh báo dữ liệu (xem mục 6). |

**Giai đoạn "đang mở"**: `Tiếp cận`, `Đủ điều kiện`, `Soạn đề xuất`, `Thương lượng`, `Tạm dừng`. "Đã đóng": `Thắng`, `Thua`.

---

## 5. `Snapshots.csv` — Chỉ mục bản chụp web

| Cột | Ý nghĩa |
|---|---|
| `snapshot_code` | Mã duy nhất, dạng `S15a`, `S15b`... |
| `company_code` | Công ty sở hữu. |
| `version` | `before` (trước) hoặc `after` (sau). |
| `source_url` | URL gốc trên Internet của trang được chụp. |
| `captured_at` | Ngày chụp thật (từ Wayback Machine) hoặc ngày danh nghĩa nếu là bản tự dựng (xem mục 6). |
| `file_name` | Tên file `.html` tương ứng trong thư mục `snapshot/`. |
| `news_type` | Chỉ điền ở dòng `after`, một trong 6 loại: `gọi vốn`, `nhân sự cấp cao`, `mở rộng`, `tuyển dụng`, `mảng kinh doanh mới`, `khác`. Trống nếu trang không có tin mới (ca đối chứng). |
| `key_quote` | Câu trích **nguyên văn** làm bằng chứng cho tin mới — **đã kiểm chứng tồn tại y hệt** (từng ký tự) trong file `after` tương ứng. Trống ở dòng `before` và ở các ca đối chứng. |
| `notes` | Ghi chú thêm: lý do không có tin mới, cảnh báo trang đổi cấu trúc, nguồn gốc bản tự dựng, v.v. |

Mỗi công ty có 3–4 trang (trang chủ + 2–3 trang con: tin tức, hồ sơ công ty, tuyển dụng, sản phẩm...), mỗi trang một cặp `before`/`after` — trừ vài trường hợp thiếu 1 vế (xem mục 7).

---

## 6. Nguồn gốc bản chụp `before` — quan trọng khi kiểm tra dữ liệu

Có **hai loại** file `before` trong `snapshot/`, phân biệt bằng cách mở file:

1. **Capture thật từ Wayback Machine** (đa số) — có script `bundle-playback.js` của archive.org chèn ở đầu file, `captured_at` là ngày capture thật.
2. **Bản tự dựng** (**50/172 file**, tất cả đều thuộc `before`) — dùng khi Wayback Machine sập kéo dài hoặc site chặn cả live lẫn Wayback replay. Cách dựng: lấy chính file `after` thật, gỡ đi các khối HTML (tin tức/link) có ngày tháng 7–8/2026, phần còn lại giữ nguyên. Nhờ vậy diff giữa hai bản vẫn ra đúng tin thật mới, cấu trúc trang vẫn là cấu trúc thật, và `key_quote` vẫn grep được nguyên văn trên `after`. Mỗi file loại này có dòng đầu tiên:
   ```html
   <!-- ban-truoc-tai-tao: dựng từ bản live 2026-08-14/15 vì Wayback không truy cập được; ... -->
   ```
   `captured_at` của các dòng này ghi ngày danh nghĩa **2026-06-30**.

Không có file `after` nào bị dựng — mọi bản `after` đều là nội dung thật (từ trang live hoặc, với 2 trang bị chặn bot hoàn toàn, từ capture Wayback thật gần nhất).

---

## 7. Các trường hợp đặc biệt cần biết

- **C32 (CY&SONS)** — không có website riêng (chỉ LinkedIn), nên **không có bản chụp web nào**. Công ty này có 2 cơ hội mở (`O19`, `O20`) nhưng không dùng được cho kịch bản "đổi phiên bản trang web" (T-6/T-7 trong PRD) — nên chọn công ty khác để demo tính năng đó.
- **C24 (MUJI/良品計画)** — trang live chặn bởi Vercel Security Checkpoint (JS challenge), Wayback replay cũng rất chập chờn. Chỉ lấy được **1 cặp trang thật** (`corporate` — trang giới thiệu công ty), và đây là ca site đổi thiết kế toàn phần giữa 2 lần chụp nên **không có `key_quote`** (không ép ra tin giả) — xếp làm ca thử thách "trang đổi cấu trúc". C24 không có cơ hội nào gán vào nên không chặn bất kỳ test case nào.
- **C29 (Nakasha)** và **C35 (Benesse HD, trang `hd-information`)** — trang tin tức nạp danh sách bằng JavaScript nên bản HTML tĩnh không chứa được nội dung tin; đây là ca thử thách "hệ thống phải nhận ra không đọc được" chứ không phải lỗi.
- **9 công ty** (`C15`–`C39`, xem cột `notes` của `Opps.csv`, đánh dấu ⚠️) có `company_code` của cơ hội được **suy luận lại** từ nội dung deal (dữ liệu gốc do lỗi tự động điền bị gán sai công ty) — sales tương ứng nên xác nhận lại.
- **14/15 cơ hội thật** có `stage` gốc là chữ tự do (ví dụ `"Đã đề xuất, chờ kết quả"`) đã được **chuẩn hoá về đúng 7 giai đoạn** theo PRD — mỗi dòng bị đổi đều ghi rõ giá trị gốc trong `notes`.

---

## 8. Cách liên kết các file

```
Account.csv (company_code)
  │
  ├─< Contacts.csv (company_code → contact_code)
  │       │
  ├─< Opps.csv (company_code, primary_contact_code → contact_code)
  │
  └─< Snapshots.csv (company_code → snapshot/<file_name>)
```

Không có mã mồ côi ở bất kỳ chiều nào (đã kiểm tra chéo toàn bộ trước khi đóng gói).
